btcutil
=======

Utility functions for Bitcoin elliptic curve cryptography.

Install with

    go get github.com/mndrix/btcutil
