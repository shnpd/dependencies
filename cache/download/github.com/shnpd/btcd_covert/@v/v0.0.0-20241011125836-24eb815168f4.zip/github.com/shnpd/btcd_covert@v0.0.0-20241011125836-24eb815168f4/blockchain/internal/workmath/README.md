workmath
==========

[![Build Status](https://github.com/btcsuite/btcd/workflows/Build%20and%20Test/badge.svg)](https://github.com/btcsuite/btcd/actions)
[![ISC License](http://img.shields.io/badge/license-ISC-blue.svg)](http://copyfree.org)
[![GoDoc](https://img.shields.io/badge/godoc-reference-blue.svg)](https://pkg.go.dev/github.com/btcsuite/btcd/workmath)

Package workmath provides utility functions that are related with calculating
the work from difficulty bits.  This package was introduced to avoid import
cycles in btcd.

## License

Package workmath is licensed under the [copyfree](http://copyfree.org) ISC
License.
