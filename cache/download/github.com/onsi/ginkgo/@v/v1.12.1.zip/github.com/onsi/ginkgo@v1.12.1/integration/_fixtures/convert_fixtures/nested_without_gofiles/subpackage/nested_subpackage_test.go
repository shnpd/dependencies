package subpackage

import (
	"testing"
)

func TestNestedSubPackages(t *testing.T) {
	t.Fail(true)
}
